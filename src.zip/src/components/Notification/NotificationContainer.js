import { MainContext } from "context/MainContext";
import React, { useContext } from "react";
import { ToastContainer } from "react-toastify";


const NotificationContainer = () => {
  return (
    <div>
      <ToastContainer />
    </div>
  );
};

export default NotificationContainer;
